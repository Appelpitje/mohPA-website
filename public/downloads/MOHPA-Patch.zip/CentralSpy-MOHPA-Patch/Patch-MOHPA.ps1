<#
.SYNOPSIS
    Medal of Honor: Pacific Assault — CentralSpy client patcher (Windows).
#>
[CmdletBinding()]
param (
    [string]$GameDir = ".",
    [Alias("Ip")]
    [string]$Master = "masterserver.mohpa.net",
    [switch]$Restore
)

$ErrorActionPreference = "Stop"
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host " MOHPA CentralSpy client patcher" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan

# High-performance native byte replacement in .NET/C# (< 10 ms per 10MB)
Add-Type -TypeDefinition @'
using System;
public static class FastPatcher {
    public static int Replace(byte[] data, byte[] oldBytes, byte[] newBytes) {
        if (oldBytes.Length != newBytes.Length) throw new ArgumentException("length mismatch");
        int count = 0;
        int max = data.Length - oldBytes.Length;
        for (int i = 0; i <= max; i++) {
            bool match = true;
            for (int j = 0; j < oldBytes.Length; j++) {
                if (data[i + j] != oldBytes[j]) { match = false; break; }
            }
            if (match) {
                Buffer.BlockCopy(newBytes, 0, data, i, newBytes.Length);
                count++;
                i += oldBytes.Length - 1;
            }
        }
        return count;
    }
}
'@

function Replace-Bytes([byte[]]$bytes, [byte[]]$old, [byte[]]$new) {
    return [FastPatcher]::Replace($bytes, $old, $new)
}

function Padded-Host([string]$hostName, [int]$length) {
    $raw = [System.Text.Encoding]::ASCII.GetBytes($hostName)
    if (($raw.Length + 1) -gt $length) { return $null }
    $out = New-Object byte[] $length
    [Array]::Copy($raw, $out, $raw.Length)
    return $out
}

function Find-Bytes([byte[]]$data, [byte[]]$pat) {
    $max = $data.Length - $pat.Length
    for ($i = 0; $i -le $max; $i++) {
        $ok = $true
        for ($j = 0; $j -lt $pat.Length; $j++) {
            if ($data[$i + $j] -ne $pat[$j]) { $ok = $false; break }
        }
        if ($ok) { return $i }
    }
    return -1
}

function Patch-Sb2GoaBridge([byte[]]$bytes) {
    # CentralSpy :28910 speaks GOA, not SB2. Same cave as patcher.py.
    $hookPat = [byte[]](0x0F,0xB6,0x07,0x35,0xEC,0x00,0x00,0x00)
    $hook = Find-Bytes $bytes $hookPat
    if ($hook -lt 0) { return $false }
    if ($bytes[$hook] -eq 0xE9) { return $false }

    $eLfanew = [BitConverter]::ToInt32($bytes, 0x3C)
    $optSize = [BitConverter]::ToUInt16($bytes, $eLfanew + 20)
    $sec = $eLfanew + 24 + $optSize
    $vsize = [BitConverter]::ToUInt32($bytes, $sec + 8)
    $newVsize = 0x7B3000
    if ($vsize -lt $newVsize) {
        [BitConverter]::GetBytes([uint32]$newVsize).CopyTo($bytes, $sec + 8)
    }

    $caveFile = 0x7B3C00
    $caveVa = [int64]0x00BB3C00
    $hookVa = [int64]0x00401000 + ($hook - 0x1000)
    $rel = [int]($caveVa - ($hookVa + 5))
    $jmp = [byte[]](0xE9,0,0,0,0,0x90,0x90,0x90)
    [BitConverter]::GetBytes($rel).CopyTo($jmp, 1)

    $caveHex = "803f5c740d0fb60735ec000000e9e17e8aff5351525781ec000800006a00685400000068203dbb00ffb6a0040000ff15cc44bb006a00681f00000068753dbb00ffb6a0040000ff15cc44bb00bf2800000033ed6a0068000800008d44240850ffb6a0040000ff157044bb0083f8067d116a14e8d91f8aff83c4044f85ff75d4eb6289c189e231db8d43063bc17755813c1a5c66696e7433803c1a5c742a51520fb7441a0450ff341a56e882618aff83c40c85c0740b5056e8c4768aff83c408455a5983c306ebc043ebbd8d43073bc1730489c3ebb285ed750a4f85ff7405e970ffffffc786b805000005000000c70602000000ffb684040000ff357486d3006a0356ff968004000083c41081c4000800005f5a595b33ede9de808aff909090905c67616d656e616d655c6d6f6870615c67616d657665725c325c6c6f636174696f6e5c305c76616c69646174655c2b517a5646432b625c656e63747970655c305c66696e616c5c5c717565727969645c312e315c005c6c6973745c636d705c67616d656e616d655c6d6f6870615c66696e616c5c"
    $cave = New-Object byte[] ($caveHex.Length / 2)
    for ($i = 0; $i -lt $cave.Length; $i++) {
        $cave[$i] = [Convert]::ToByte($caveHex.Substring($i * 2, 2), 16)
    }
    if (($caveFile + $cave.Length) -gt $bytes.Length) { return $false }
    [Buffer]::BlockCopy($cave, 0, $bytes, $caveFile, $cave.Length)
    [Buffer]::BlockCopy($jmp, 0, $bytes, $hook, $jmp.Length)
    return $true
}

function Patch-GethostbynameRedirect([byte[]]$bytes, [string]$hostName) {
    $thunkPat = [byte[]](0xFF,0x25,0x7C,0x44,0xBB,0x00)
    $thunk = Find-Bytes $bytes $thunkPat
    if ($thunk -lt 0) { return $false }
    if ($bytes[$thunk] -eq 0xE9) { return $false }

    $eLfanew = [BitConverter]::ToInt32($bytes, 0x3C)
    $optSize = [BitConverter]::ToUInt16($bytes, $eLfanew + 20)
    $sec = $eLfanew + 24 + $optSize
    $vsize = [BitConverter]::ToUInt32($bytes, $sec + 8)
    if ($vsize -lt 0x7B3000) {
        [BitConverter]::GetBytes([uint32]0x7B3000).CopyTo($bytes, $sec + 8)
    }

    $caveFile = 0x7B3E00
    $caveVa = [int64]0x00BB3E00
    $thunkVa = [int64]0x00401000 + ($thunk - 0x1000)
    $iat = [uint32]0x00BB447C

    $ms = New-Object System.IO.MemoryStream
    $hdr = [byte[]](0x8B,0x44,0x24,0x04,0x85,0xC0,0x74,0x15,0x0F,0xB6,0x08,0x83,0xF9,0x30,0x72,0x05,0x83,0xF9,0x39,0x76,0x08)
    $ms.Write($hdr, 0, $hdr.Length)
    $redirOff = [int]$ms.Length
    $movArg = [byte[]](0xC7,0x44,0x24,0x04,0,0,0,0)
    $ms.Write($movArg, 0, $movArg.Length)
    $iatBytes = [BitConverter]::GetBytes($iat)
    $jmpIat = [byte[]](0xFF,0x25,0,0,0,0)
    [Buffer]::BlockCopy($iatBytes, 0, $jmpIat, 2, 4)
    $ms.Write($jmpIat, 0, $jmpIat.Length)
    while (($ms.Length -band 3) -ne 0) { $ms.WriteByte(0x90) }
    $nameOff = [int]$ms.Length
    $name = [System.Text.Encoding]::ASCII.GetBytes($hostName)
    $ms.Write($name, 0, $name.Length)
    $ms.WriteByte(0)

    $cave = $ms.ToArray()
    [BitConverter]::GetBytes([uint32]($caveVa + $nameOff)).CopyTo($cave, $redirOff + 4)

    if (($caveFile + $cave.Length) -gt $bytes.Length) { return $false }
    [Buffer]::BlockCopy($cave, 0, $bytes, $caveFile, $cave.Length)
    $rel = [int]($caveVa - ($thunkVa + 5))
    $jmp = [byte[]](0xE9,0,0,0,0,0x90)
    [BitConverter]::GetBytes($rel).CopyTo($jmp, 1)
    [Buffer]::BlockCopy($jmp, 0, $bytes, $thunk, $jmp.Length)
    return $true
}

function Patch-IsStats([byte[]]$bytes) {
    $count = 0
    for ($i = 0; $i -le $bytes.Length - 15; $i++) {
        if ($bytes[$i] -eq 0x8B -and $bytes[$i+1] -eq 0x0D -and
            $bytes[$i+6] -eq 0x33 -and $bytes[$i+7] -eq 0xC0 -and
            $bytes[$i+8] -eq 0x83 -and $bytes[$i+9] -eq 0xF9 -and $bytes[$i+10] -eq 0xFF -and
            $bytes[$i+11] -eq 0x0F -and $bytes[$i+12] -eq 0x95 -and $bytes[$i+13] -eq 0xC0 -and
            $bytes[$i+14] -eq 0xC3) {
            $patch = [byte[]](0xB8,0x01,0x00,0x00,0x00,0xC3,0x90,0x90,0x90,0x90,0x90,0x90,0x90,0x90,0x90)
            for ($j = 0; $j -lt 15; $j++) { $bytes[$i + $j] = $patch[$j] }
            $count++
            $i += 14
        }
    }
    return $count
}

function Patch-File([string]$path, [bool]$isServer, [string]$ip) {
    $bak = "$path.bak"
    if (-not (Test-Path $bak)) {
        if (-not (Test-Path $path)) { return }
        Copy-Item $path $bak
        Write-Host "[+] backup $bak" -ForegroundColor Green
    } else {
        Write-Host "[*] backup exists $bak" -ForegroundColor Yellow
    }
    # Always read from clean backup to prevent stacked/corrupted patches
    $bytes = [System.IO.File]::ReadAllBytes((Resolve-Path $bak))

    $n = Replace-Bytes $bytes ([byte[]](0x85,0xC0,0x7D,0x0C,0xC7,0x86,0x18,0x01,0x00,0x00,0x03,0x10,0x00,0x00)) ([byte[]](0x85,0xC0,0xEB,0x0C,0xC7,0x86,0x18,0x01,0x00,0x00,0x03,0x10,0x00,0x00))
    if ($n -gt 0) { Write-Host "    - DirtySDK SSL bypass ($n)" }

    $n = Replace-Bytes $bytes ([byte[]](0x68,0x0B,0x1A,0x00,0x00,0x68)) ([byte[]](0x68,0x5E,0x47,0x00,0x00,0x68))
    if ($n -gt 0) { Write-Host "    - peerchat port 6667 -> 18270 ($n)" }

    $n = Patch-IsStats $bytes
    if ($n -gt 0) { Write-Host "    - IsStatsConnected always-true ($n)" }

    # Master server and availability direct IP
    $masterTargets = @(
        "%s.available.gamespy.com", "%s.available.openspy.net", "%s.available.fesl.ea.com",
        "%s.master.gamespy.com", "%s.master.openspy.net", "%s.master.fesl.ea.com",
        "%s.ms%d.gamespy.com", "%s.ms%d.openspy.net", "%s.ms%d.fesl.ea.com"
    )
    foreach ($m in $masterTargets) {
        $old = [System.Text.Encoding]::ASCII.GetBytes($m)
        $new = Padded-Host $ip $old.Length
        if ($null -eq $new) { continue }
        $n = Replace-Bytes $bytes $old $new
        if ($n -gt 0) { Write-Host "    - $m -> $ip ($n)" }
    }

    $domains = @(
        @("motd.gamespy.com", "motd.fesl.ea.com"),
        @("motd.openspy.net", "motd.fesl.ea.com")
    )
    foreach ($d in $domains) {
        $old = [System.Text.Encoding]::ASCII.GetBytes($d[0])
        $new = [System.Text.Encoding]::ASCII.GetBytes($d[1])
        $n = Replace-Bytes $bytes $old $new
        if ($n -gt 0) { Write-Host "    - $($d[0]) -> $($d[1]) ($n)" }
    }

    $motdPrefixes = @("http://motd.gamespy.com", "http://motd.fesl.ea.com", "http://motd.openspy.net", "http://www.mohaa.ea.com")
    $motdRaw = [System.Text.Encoding]::ASCII.GetBytes("http://$ip")
    foreach ($p in $motdPrefixes) {
        $motdOld = [System.Text.Encoding]::ASCII.GetBytes($p)
        if ($motdRaw.Length -gt $motdOld.Length) { continue }
        $motdNew = New-Object byte[] $motdOld.Length
        [Array]::Copy($motdRaw, $motdNew, $motdRaw.Length)
        for ($i = $motdRaw.Length; $i -lt $motdNew.Length; $i++) { $motdNew[$i] = [byte][char]'/' }
        $n = Replace-Bytes $bytes $motdOld $motdNew
        if ($n -gt 0) { Write-Host "    - $p -> $([System.Text.Encoding]::ASCII.GetString($motdNew)) ($n)" }
    }

    $direct = @(
        "gpcm.gamespy.com", "gpcm.openspy.net",
        "gpsp.gamespy.com", "gpsp.openspy.net",
        "gamestats.gamespy.com", "gamestats.openspy.net",
        "peerchat.gamespy.com", "peerchat.openspy.net",
        "mohpa.fesl.ea.com"
    )
    foreach ($h in $direct) {
        $old = [System.Text.Encoding]::ASCII.GetBytes($h)
        $new = Padded-Host $ip $old.Length
        if ($null -eq $new) { continue }
        $n = Replace-Bytes $bytes $old $new
        if ($n -gt 0) { Write-Host "    - $h -> $ip ($n)" }
    }

    # Restore any 333networks redirected pointers if present
    $redirects = @(
        @([byte[]](0x40,0x7A,0xCE,0x00), [byte[]](0x24,0x09,0xBC,0x00)),
        @([byte[]](0x5D,0x7A,0xCE,0x00), [byte[]](0x00,0x0A,0xBC,0x00)),
        @([byte[]](0x77,0x7A,0xCE,0x00), [byte[]](0x44,0x0C,0xBC,0x00)),
        @([byte[]](0xBA,0x7A,0xCE,0x00), [byte[]](0xC0,0x33,0xCF,0x00)),
        @([byte[]](0xCB,0x7A,0xCE,0x00), [byte[]](0x08,0x35,0xCF,0x00)),
        @([byte[]](0x8F,0x7A,0xCE,0x00), [byte[]](0x10,0x25,0xBC,0x00)),
        @([byte[]](0xA4,0x7A,0xCE,0x00), [byte[]](0x68,0x37,0xCF,0x00))
    )
    foreach ($r in $redirects) {
        $n = Replace-Bytes $bytes $r[0] $r[1]
        if ($n -gt 0) { Write-Host "    - reverted redirected pointer ($n)" }
    }

    # Anti-freeze protocol and busy-wait fixes
    $n = Replace-Bytes $bytes ([byte[]](0x68,0x4A,0x0E,0x00,0x00,0x68,0x14,0x0F,0xC9,0x00,0xE8,0xD5,0x69,0x00,0x00)) ([byte[]](0x68,0x4A,0x0E,0x00,0x00,0x68,0x14,0x0F,0xC9,0x00,0x31,0xC0,0x90,0x90,0x90))
    if ($n -gt 0) { Write-Host "    - demangler TCP 3658 connect skip ($n)" }

    $n = Replace-Bytes $bytes ([System.Text.Encoding]::ASCII.GetBytes("demangler.ea.com")) ([byte[]](0x31,0x32,0x37,0x2E,0x30,0x2E,0x30,0x2E,0x31,0x00,0x00,0x00,0x00,0x00,0x00,0x00))
    if ($n -gt 0) { Write-Host "    - demangler.ea.com -> 127.0.0.1 fail-fast ($n)" }

    if (Patch-GethostbynameRedirect $bytes $ip) {
        Write-Host "    - gethostbyname -> $ip (no hosts file)"
    }

    $n = Replace-Bytes $bytes ([byte[]](0x83,0xEC,0x44,0xA1,0x78,0x06,0xD3,0x00,0x56,0x8B,0x74,0x24,0x4C,0xBA,0x40,0xD5,0x02,0x02)) ([byte[]](0xC7,0x05,0x20,0xD5,0x02,0x02,0x01,0x00,0x00,0x00,0x33,0xC0,0xC3,0x90,0x90,0x90,0x90,0x90))
    if ($n -gt 0) { Write-Host "    - GSIStartAvailableCheck no-op ($n)" }

    $n = Replace-Bytes $bytes ([byte[]](0x8B,0x44,0x24,0x24,0x85,0xC0,0x74,0x46,0x6A,0x01)) ([byte[]](0x8B,0x44,0x24,0x24,0x85,0xC0,0xEB,0x46,0x6A,0x01))
    if ($n -gt 0) { Write-Host "    - peer CDKey wait bypass ($n)" }

    $n = Replace-Bytes $bytes ([byte[]](0x8B,0x44,0x24,0x24,0x85,0xC0,0x74,0x4B,0xEB,0x03)) ([byte[]](0x8B,0x44,0x24,0x24,0x85,0xC0,0xEB,0x4B,0xEB,0x03))
    if ($n -gt 0) { Write-Host "    - peer connect wait bypass ($n)" }

    $extra = 0
    $extra += Replace-Bytes $bytes ([byte[]](0x74,0x46,0x6A,0x01)) ([byte[]](0xEB,0x46,0x6A,0x01))
    $extra += Replace-Bytes $bytes ([byte[]](0x85,0xC0,0x74,0x4B,0xEB,0x03)) ([byte[]](0x85,0xC0,0xEB,0x4B,0xEB,0x03))
    $extra += Replace-Bytes $bytes ([byte[]](0x74,0x4B,0xEB,0x03,0x8D,0x49,0x00,0x6A,0x01)) ([byte[]](0xEB,0x4B,0xEB,0x03,0x8D,0x49,0x00,0x6A,0x01))
    $extra += Replace-Bytes $bytes ([byte[]](0x85,0xC0,0x74,0x47,0x90,0x6A,0x01)) ([byte[]](0x85,0xC0,0xEB,0x47,0x90,0x6A,0x01))
    $extra += Replace-Bytes $bytes ([byte[]](0x74,0x48,0x8B,0xFF,0x6A,0x01)) ([byte[]](0xEB,0x48,0x8B,0xFF,0x6A,0x01))
    $extra += Replace-Bytes $bytes ([byte[]](0x74,0x48,0x8D,0x9B,0x00,0x00,0x00,0x00,0x6A,0x01)) ([byte[]](0xEB,0x48,0x8D,0x9B,0x00,0x00,0x00,0x00,0x6A,0x01))
    $extra += Replace-Bytes $bytes ([byte[]](0x74,0x49,0x8D,0x49,0x00,0x6A,0x01)) ([byte[]](0xEB,0x49,0x8D,0x49,0x00,0x6A,0x01))
    if ($extra -gt 0) { Write-Host "    - peer sync wait bypass extra ($extra)" }

    $n = Replace-Bytes $bytes ([byte[]](0xE8,0x14,0xB2,0xFD,0xFF,0x05,0x60,0xEA,0x00,0x00,0x5F,0x89,0x46,0x04)) ([byte[]](0xE8,0x14,0xB2,0xFD,0xFF,0x05,0xF4,0x01,0x00,0x00,0x5F,0x89,0x46,0x04))
    if ($n -gt 0) { Write-Host "    - peer operation timeout 60s -> 500ms ($n)" }

    $n = Replace-Bytes $bytes ([byte[]](0x39,0xB3,0xB4,0x00,0x00,0x00,0x7E,0x06,0x89,0xB3,0xB4,0x00,0x00,0x00,0x8A,0x48,0x02)) ([byte[]](0x89,0xB3,0xB4,0x00,0x00,0x00,0x8A,0x48,0x02,0x80,0xF9,0x09,0x75,0x02,0x30,0xC9,0x90))
    if ($n -gt 0) { Write-Host "    - master server UDP Type 9 auto-ack ($n)" }

    if (-not $isServer) {
        $n = Replace-Bytes $bytes ([byte[]](0x83,0xEC,0x5C,0xA1,0x78,0x06,0xD3,0x00,0x89,0x44,0x24,0x58,0xA1,0xE8,0x83,0xD3)) ([byte[]](0xC7,0x05,0x20,0xD5,0x02,0x02,0x01,0x00,0x00,0x00,0xB8,0x01,0x00,0x00,0x00,0xC3))
        if ($n -gt 0) { Write-Host "    - GameSpy availability check bypass ($n)" }

        $oldLogin = [System.Text.Encoding]::ASCII.GetBytes("mp_findgame_vet") + [byte[]](0, 0)
        $newLogin = [System.Text.Encoding]::ASCII.GetBytes("mp_account_login") + [byte[]](0)
        $n = Replace-Bytes $bytes $oldLogin $newLogin
        if ($n -gt 0) { Write-Host "    - restored mp_account_login ($n)" }
        $n = Replace-Bytes $bytes ([byte[]](0x6A,0x00,0x68,0xA8,0x4C,0xBB,0x00,0x68,0x5C,0x97,0xBB,0x00)) ([byte[]](0x6A,0x00,0x68,0xA8,0x49,0xBB,0x00,0x68,0x5C,0x97,0xBB,0x00))
        if ($n -gt 0) { Write-Host "    - intro cvar default off ($n)" }
        $n = Replace-Bytes $bytes ([byte[]](0x83,0xEC,0x24,0xA1,0x78,0x06,0xD3,0x00,0x89,0x44,0x24,0x20,0xA1,0xC0,0xE8,0x6D,0x01)) ([byte[]](0xC7,0x05,0xC0,0xE8,0x6D,0x01,0x00,0x00,0x00,0x00,0xC3,0x90,0x90,0x90,0x90,0x90,0x90))
        if ($n -gt 0) { Write-Host "    - intro skip ($n)" }
        $n = Replace-Bytes $bytes ([byte[]](0xFF,0x15,0x88,0x41,0xBB,0x00,0x3D,0xB7,0x00,0x00,0x00,0x75,0x1D)) ([byte[]](0xFF,0x15,0x88,0x41,0xBB,0x00,0x3D,0xB7,0x00,0x00,0x00,0xEB,0x1D))
        if ($n -gt 0) { Write-Host "    - mutex multi-instance bypass ($n)" }
        $n = Replace-Bytes $bytes ([byte[]](0x3B,0xF0,0x75,0x12,0x89,0x1D,0xF0,0xC4,0xD3,0x00,0xE9,0x24,0xFF,0xFF,0xFF)) ([byte[]](0x3B,0xF0,0x75,0x12,0x89,0x1D,0xF0,0xC4,0xD3,0x00,0xE9,0x2D,0x00,0x00,0x00))
        if ($n -gt 0) { Write-Host "    - master server fast FIN / anti-freeze ($n)" }
        if (Patch-Sb2GoaBridge $bytes) {
            Write-Host "    - SB2 master GOA list bridge"
        }
    }

    [System.IO.File]::WriteAllBytes((Resolve-Path $path), $bytes)
    Write-Host "[+] patched $path" -ForegroundColor Green
}

function Cleanup-ConflictingUI([string]$dir) {
    foreach ($bad in @("shell_mainmenu.urc", "mp_account_login.urc")) {
        $p = Join-Path $dir "main\ui\$bad"
        if (Test-Path $p) {
            Remove-Item $p -Force
            Write-Host "[+] removed conflicting UI override: $p" -ForegroundColor Yellow
        }
    }
    $uiDir = Join-Path $dir "main\ui"
    if ((Test-Path $uiDir) -and ((Get-ChildItem $uiDir).Count -eq 0)) {
        Remove-Item $uiDir -Force
    }
}

function Write-AutoexecFile([string]$dir) {
    $mainDir = Join-Path $dir "main"
    if (-not (Test-Path $mainDir)) { return }
    $path = Join-Path $mainDir "autoexec.cfg"
    $cfgHeader = "// CentralSpy MOHPA client`r`nseta ui_logged_in `"0`"`r`nseta ui_hide_internet `"0`"`r`nseta ui_first_time_mp `"0`"`r`nseta cl_enableGameSpyAuxiliaryQuery `"0`"`r`nseta cl_playintro `"0`"`r`n"
    $existing = ""
    if (Test-Path $path) {
        $existing = [System.IO.File]::ReadAllText($path)
        $existing = $existing -replace 'seta\s+ui_logged_in\s+\"1\"', 'seta ui_logged_in "0"'
        $existing = $existing -replace 'seta\s+cl_enableGameSpyAuxiliaryQuery\s+\"1\"', 'seta cl_enableGameSpyAuxiliaryQuery "0"'
    }
    if ($existing -match 'ui_logged_in' -and $existing -match 'cl_enableGameSpyAuxiliaryQuery' -and $existing -match 'CentralSpy') {
        [System.IO.File]::WriteAllText($path, $existing)
        Write-Host "[*] autoexec updated with clean cvars: $path" -ForegroundColor Green
        return
    }
    $body = $cfgHeader
    if ($existing.Trim()) { $body = $cfgHeader + "`r`n" + $existing }
    [System.IO.File]::WriteAllText($path, $body)
    Write-Host "[+] wrote $path" -ForegroundColor Green
}

function Find-GameDir([string]$start) {
    $d = (Resolve-Path $start).Path
    if ((Test-Path (Join-Path $d "mohpa.exe")) -or (Test-Path (Join-Path $d "mohpa.exe.bak"))) { return $d }
    $parent = Split-Path $d -Parent
    if ($parent -and ((Test-Path (Join-Path $parent "mohpa.exe")) -or (Test-Path (Join-Path $parent "mohpa.exe.bak")))) { return $parent }
    return $d
}

function Write-HostsFile([string]$dir, [string]$ip) {
    $names = @(
        "fesl.ea.com", "theater.ea.com", "mohpa.fesl.ea.com", "mohpa.theater.ea.com",
        "eagames.fesl.ea.com", "demangler.ea.com",
        "gpcm.fesl.ea.com", "gpsp.fesl.ea.com", "peerchat.fesl.ea.com",
        "gamestats.fesl.ea.com", "motd.fesl.ea.com",
        "www.mohaa.ea.com", "mohaa.ea.com",
        "mohpa.available.fesl.ea.com", "mohpa.master.fesl.ea.com",
        "mohpa.ms1.fesl.ea.com", "mohpa.ms2.fesl.ea.com",
        "mohpa.ms3.fesl.ea.com", "mohpa.ms4.fesl.ea.com",
        "gpcm.gamespy.com", "gpsp.gamespy.com", "peerchat.gamespy.com",
        "gamestats.gamespy.com", "motd.gamespy.com",
        "mohpa.available.gamespy.com", "mohpa.master.gamespy.com",
        "gpcm.openspy.net", "gpsp.openspy.net", "peerchat.openspy.net",
        "gamestats.openspy.net", "motd.openspy.net",
        "mohpa.available.openspy.net", "mohpa.master.openspy.net"
    )
    $lines = @(
        "# CentralSpy hosts - merge into C:\Windows\System32\drivers\etc\hosts",
        "# (Notepad as Administrator). Wine: drive_c\windows\system32\drivers\etc\hosts",
        ""
    )
    foreach ($n in $names) {
        $hostIp = $ip
        if ($n -eq "demangler.ea.com") { $hostIp = "127.0.0.1" }
        $lines += ("{0,-15}  {1}" -f $hostIp, $n)
    }
    $path = Join-Path $dir "centralspy-hosts.txt"
    $lines -join "`r`n" | Set-Content -Path $path -Encoding ASCII
    Write-Host "[+] wrote $path" -ForegroundColor Green
}

$gameDir = Find-GameDir $GameDir
$client = Join-Path $gameDir "mohpa.exe"
$server = Join-Path $gameDir "mohpa_server.exe"
Write-Host " dir $gameDir"
Write-Host " host $Master"
Write-Host ""

function Get-RealPython {
    foreach ($name in @("py", "python3", "python")) {
        $cmd = Get-Command $name -ErrorAction SilentlyContinue
        if (-not $cmd) { continue }
        if ($cmd.Source -match "WindowsApps") { continue }
        return $cmd.Source
    }
    return $null
}

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $scriptDir) { $scriptDir = (Get-Location).Path }
$patcherPy = Join-Path $scriptDir "patcher.py"
$python = Get-RealPython
if ($python -and (Test-Path $patcherPy)) {
    Write-Host "[*] using $python (full patcher.py)" -ForegroundColor Cyan
    $pyArgs = @()
    if ((Split-Path $python -Leaf) -match "^py(\.exe)?$") { $pyArgs += "-3" }
    $pyArgs += $patcherPy, $gameDir
    if ($Restore) { $pyArgs += "--restore" } else { $pyArgs += "--host", $Master }
    & $python @pyArgs
    exit $LASTEXITCODE
}

if ($Restore) {
    $ok = $false
    foreach ($p in @($client, $server)) {
        if (Test-Path "$p.bak") {
            Copy-Item "$p.bak" $p -Force
            Write-Host "[+] restored $p" -ForegroundColor Green
            $ok = $true
        }
    }
    if (-not $ok) {
        Write-Host "[-] no .bak files found" -ForegroundColor Red
        exit 1
    }
    return
}

if (-not (Test-Path $client) -and -not (Test-Path "$client.bak") -and -not (Test-Path $server) -and -not (Test-Path "$server.bak")) {
    Write-Host "[-] mohpa.exe not found in $gameDir" -ForegroundColor Red
    Write-Host "    Copy this folder next to mohpa.exe, or run: Patch-MOHPA.ps1 -GameDir D:\Games\MOHPA" -ForegroundColor Yellow
    exit 1
}

if ((Test-Path $client) -or (Test-Path "$client.bak")) { Patch-File $client $false $Master }
if ((Test-Path $server) -or (Test-Path "$server.bak")) { Patch-File $server $true $Master }
Cleanup-ConflictingUI $gameDir
Write-AutoexecFile $gameDir

Write-Host ""
Write-Host "[+] done. Fully quit the game, relaunch, and log in. No hosts-file edits are required." -ForegroundColor Green
