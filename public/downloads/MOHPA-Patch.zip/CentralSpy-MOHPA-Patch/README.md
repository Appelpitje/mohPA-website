# Medal of Honor: Pacific Assault — CentralSpy client patch

Patches official **MOHPA v1.2** so it can **log in and play on CentralSpy**.

Works on **GOG, Origin/EA App, and retail disc** as long as `mohpa.exe` is the official **1.2** build (ProductVersion `1, 2, 1, 280`). The storefront does not matter. **1.0 / 1.1** need EA’s 1.2 patch first. Cracked / no-CD executables are not supported.

A patched 1.2 client can:

- log in on the real Multiplayer account screen
- see CentralSpy internet servers in the in-game browser
- join and play

**No hosts-file edits and no hardcoded IP.** The client looks up **`masterserver.mohpa.net`**. Leftover EA/GameSpy names (`fesl.ea.com`, `gpcm.gamespy.com`, …) are redirected to that hostname through a `gethostbyname` hook.

## What it changes

| Change | Why |
| --- | --- |
| DirtySDK SSL verify bypass | MOHPA’s 2004 SSL 2.0 stack rejects CentralSpy’s cert otherwise |
| Peerchat port **6667 → 18270** | TCP 6667 is blocked on many ISPs; CentralSpy publishes 18270 |
| `IsStatsConnected()` always true | After chat welcome the exe aborts community login if gstats was not already up |
| GameSpy / FESL hostnames → `masterserver.mohpa.net` | Direct strings where they fit, plus a `gethostbyname` hook; no hosts file |
| Skip `demangler.ea.com:3658` | CentralSpy does not listen there; a blocking `connect()` froze the GUI ~20s |
| GOA list bridge on master port 28910 | CentralSpy speaks GameSpy GOA, not SB2; without this the internet server list stays empty |
| Keeps `mp_account_login` | You log in with a CentralSpy account in-game |

It does **not** skip the EA login screen. That screen is the point.

Default host: `masterserver.mohpa.net`. Override with `--host`.

Download the full zip (not only the `.bat`):
`https://centralspy.appelpitje.dev/downloads/CentralSpy-MOHPA-Patch.zip`

The `.bat` is a launcher. It needs `Patch-MOHPA.ps1` and `patcher.py` in the same folder.

## Install (Windows)

1. Confirm you have **v1.2**. GOG is already 1.2. Origin/EA App usually is. Retail disc: install EA’s 1.0→1.2 (or 1.1→1.2) patch first.
2. Extract this folder into your game directory (the folder that contains `mohpa.exe`).
3. Double-click **`Patch-MOHPA.bat`**.
4. Fully quit the game (and Wine), then launch `mohpa.exe`.
5. Multiplayer → log in with your CentralSpy account.
6. Open the internet server list. You should see CentralSpy servers.

On Windows you do **not** need Python. `Patch-MOHPA.bat` runs PowerShell (the Microsoft Store `python` stub is ignored). If a real Python 3 is installed, it uses `patcher.py` instead.

```bash
python patcher.py
python patcher.py "D:\Games\MOHPA" --host masterserver.mohpa.net
python patcher.py --restore
```

If you previously merged `centralspy-hosts.txt` into your hosts file, you can delete those lines. They are no longer used.

## Ports the player’s network must allow

| Port | Protocol | Service |
| --- | --- | --- |
| 18020 | TCP | FESL login |
| 18275 | TCP | Theater |
| 18270 | TCP | Peerchat (patched client) |
| 29900 | TCP | GameSpy presence (GPCM) |
| 29920 | TCP | GameSpy stats |
| 27900 | UDP | GameSpy availability |
| 27900 | TCP | GameSpy master |
| 80 | TCP | GameSpy MOTD / vercheck (HTTP, not HTTPS) |
| 28910 | TCP | Server browser master (GOA on CentralSpy) |
| 3658 | TCP | EA NAT demangler. CentralSpy does not serve this; the patch skips the connect. |

## Revert

`Restore-Original.bat`, or `python patcher.py --restore`, or rename `mohpa.exe.bak` back to `mohpa.exe`.

## Dedicated server

Patch `mohpa_server.exe` with the same tool (it is patched automatically if present). Heartbeats go to `masterserver.mohpa.net`.
