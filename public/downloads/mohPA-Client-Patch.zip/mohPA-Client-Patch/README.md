# Medal of Honor: Pacific Assault — mohPA client patch

Patches a stock **MOHPA v1.2** client (GOG / Origin / disc) so it can **log in and play on mohPA**.

A patched 1.2 client can:

- log in on the real Multiplayer account screen
- see mohPA internet servers in the in-game browser
- join and play

## What it changes

| Change | Why |
| --- | --- |
| DirtySDK SSL verify bypass | MOHPA’s 2004 SSL 2.0 stack rejects mohPA’s cert otherwise |
| Peerchat port **6667 → 18270** | TCP 6667 is blocked on many ISPs; mohPA publishes 18270 |
| `IsStatsConnected()` always true | After chat welcome the exe aborts community login if gstats was not already up |
| `gpcm` / `gpsp` / `gamestats` / `peerchat` → mohPA IPv4 | GameSpy SDK connects by those raw host strings (hosts file is not enough) |
| Skip `demangler.ea.com:3658` | mohPA does not listen there; a blocking `connect()` froze the GUI ~20s |
| GOA list bridge on master port 28910 | mohPA speaks GameSpy GOA, not SB2; without this the internet server list stays empty |
| Keeps `mp_account_login` | You log in with a mohPA account in-game |

It does **not** skip the EA login screen. That screen is the point.

Default server: `178.105.150.25`. Override with `--ip`.

Download the full zip (not only the `.bat`):
`https://portal.mohpa.net/downloads/mohPA-Client-Patch.zip`

The `.bat` is a launcher. It needs `Patch-MOHPA.ps1` and `patcher.py` in the same folder.

## Install (Windows)

1. Extract this folder into your game directory (the folder that contains `mohpa.exe`).
2. Double-click **`Patch-MOHPA.bat`**.
3. Merge **`mohpa-hosts.txt`** into:
   - Windows: `C:\Windows\System32\drivers\etc\hosts` (run Notepad as Administrator)
   - Wine / Whisky: `<bottle>/drive_c/windows/system32/drivers/etc/hosts`
4. Fully quit the game (and Wine), then launch `mohpa.exe`.
5. Multiplayer → log in with your mohPA account.
6. Open the internet server list. You should see mohPA servers.

On Windows you do **not** need Python. `Patch-MOHPA.bat` runs PowerShell (the Microsoft Store `python` stub is ignored). If a real Python 3 is installed, it uses `patcher.py` instead.

```bash
python patcher.py
python patcher.py "D:\Games\MOHPA" --ip 178.105.150.25
python patcher.py --restore
```

## Ports the player’s network must allow

| Port | Protocol | Service |
| --- | --- | --- |
| 18020 | TCP | FESL login |
| 18275 | TCP | Theater |
| 18270 | TCP | Peerchat (patched client) |
| 29900 | TCP | GameSpy presence (GPCM) |
| 29920 | TCP | GameSpy stats |
| 27900 | UDP | GameSpy availability |
| 27900 | TCP | GameSpy master (MOHPA uses this, not 28900) |
| 80 | TCP | GameSpy MOTD / vercheck (HTTP, not HTTPS) |
| 28910 | TCP | Server browser master (GOA on mohPA) |
| 3658 | TCP | EA NAT demangler. mohPA does not serve this; the patch skips the connect. Do **not** hosts-file it to the master IP (that is a ~20s freeze) |

## Revert

`Restore-Original.bat`, or `python patcher.py --restore`, or rename `mohpa.exe.bak` back to `mohpa.exe`.

## Dedicated server

Patch `mohpa_server.exe` with the same tool (it is patched automatically if present). Point its hosts file at the same mohPA IP. Heartbeats go to `mohpa.master.fesl.ea.com`.
