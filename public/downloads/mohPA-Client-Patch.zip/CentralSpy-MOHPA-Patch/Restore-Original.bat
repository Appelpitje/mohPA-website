@echo off
title Restore original MOHPA executables
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Patch-MOHPA.ps1" -Restore
echo.
pause
