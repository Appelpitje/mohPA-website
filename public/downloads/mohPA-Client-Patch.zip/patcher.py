#!/usr/bin/env python3
"""
Medal of Honor: Pacific Assault — mohPA client patcher.

Patches mohpa.exe (and mohpa_server.exe) so a stock GOG / Origin / disc
v1.2 client can log in through mohPA FESL and play, without OpenSpy.

Required binary changes (proven on a live MOHPA 1.2 login):
  1. DirtySDK SSL verify bypass (7D -> EB) so Netscape SSL 2.0 accepts mohPA
  2. Peerchat TCP port 6667 -> 18270 (6667 is filtered on many ISPs)
  3. IsStatsConnected() always true (community login otherwise fails after chat)
  4. GameSpy hostnames -> mohPA IPv4 / fesl.ea.com (same-length replacements)

Optional: mutex bypass, intro skip. The in-game FESL login screen is kept.
"""

from __future__ import annotations

import argparse
import os
import re
import shutil
import struct
import sys
from typing import List, Sequence

DEFAULT_IP = "178.105.150.25"
PEERCHAT_PORT = 18270

# GameSpy master and availability format strings.
# Overwritten with direct IPv4 NUL-padded so gethostbyname parses the IP directly
# without any DNS latency or failure on the main game thread.
MASTER_DOMAINS = [
    b"%s.available.gamespy.com",
    b"%s.available.openspy.net",
    b"%s.available.fesl.ea.com",
    b"%s.master.gamespy.com",
    b"%s.master.openspy.net",
    b"%s.master.fesl.ea.com",
    b"%s.ms%d.gamespy.com",
    b"%s.ms%d.openspy.net",
    b"%s.ms%d.fesl.ea.com",
]

DOMAIN_REPLACEMENTS = [
    (b"motd.gamespy.com", b"motd.fesl.ea.com"),
    (b"motd.openspy.net", b"motd.fesl.ea.com"),
]

# 2004 ghttpThink does a blocking gethostbyname on the game thread. Point
# MOTD at the IPv4 so Windows cannot stall ~20s per menu action on DNS.
MOTD_HTTP_PREFIXES = [
    b"http://motd.gamespy.com",
    b"http://motd.fesl.ea.com",
    b"http://motd.openspy.net",
]

# GameSpy SDK connect targets. Overwritten with the mohPA IPv4, NUL-padded.
# Hosts-file DNS is not enough: gpcm/gpsp/gamestats/peerchat are used as raw
# connect strings (and are XOR-decoded into .data at runtime).
DIRECT_CONNECT_HOSTS = [
    b"gpcm.gamespy.com",
    b"gpcm.openspy.net",
    b"gpsp.gamespy.com",
    b"gpsp.openspy.net",
    b"gamestats.gamespy.com",
    b"gamestats.openspy.net",
    b"peerchat.gamespy.com",
    b"peerchat.openspy.net",
    b"mohpa.fesl.ea.com",
]

# DirtySDK: JGE after SSL verify -> JMP (skip EA CA failure).
SSL_BYPASS = (
    bytes.fromhex("85c07d0cc7861801000003100000"),
    bytes.fromhex("85c0eb0cc7861801000003100000"),
)

# push 6667; push <hostname>  ->  push 18270; push <hostname>
PUSH_PEERCHAT_PORT = (
    bytes.fromhex("680b1a000068"),
    bytes.fromhex("685e47000068"),
)

# IsStatsConnected: mov ecx,[sock]; xor eax,eax; cmp ecx,-1; setne al; ret
# -> mov eax,1; ret; nops
ISSTATS_RE = re.compile(
    bytes.fromhex("8b0d") + b"...." + bytes.fromhex("33c083f9ff0f95c0c3"),
    re.DOTALL,
)
ISSTATS_PATCH = bytes.fromhex("b801000000c3") + b"\x90" * 9

MUTEX_BYPASS = (
    bytes.fromhex("ff158841bb003db7000000751d"),
    bytes.fromhex("ff158841bb003db7000000eb1d"),
)

INTRO_CVAR_DEFAULT = (
    bytes.fromhex("6a0068a84cbb00685c97bb00"),
    bytes.fromhex("6a0068a849bb00685c97bb00"),
)

INTRO_FUNCTION_SKIP = (
    bytes.fromhex("83ec24a17806d30089442420a1c0e86d01"),
    bytes.fromhex("c705c0e86d0100000000c3909090909090"),
)

# GameSpy master reader: when \final\ is parsed, immediately close socket
# instead of looping and hanging 20s waiting for TCP FIN from server.
MASTER_RECV_FAST_FIN = (
    bytes.fromhex("3bf07512891df0c4d300e924ffffff"),
    bytes.fromhex("3bf07512891df0c4d300e92d000000"),
)

# Anti-freeze: bypass GameSpy availability UDP busy-wait loop (msleep 5ms up to 4s)
GSAVALCHECK_BYPASS = (
    bytes.fromhex("83ec5ca17806d30089442458a1e883d3"),
    bytes.fromhex("c70520d5020201000000b801000000c3"),
)

# Anti-freeze: GSIStartAvailableCheck is a no-op (Think is already forced Available).
# Unique because of mov edx, GSIACResult+0x20 (0x0202D540).
GSASTART_BYPASS = (
    bytes.fromhex("83ec44a17806d300568b74244cba40d50202"),
    bytes.fromhex("c70520d502020100000033c0c39090909090"),
)

# Anti-freeze: skip blocking TCP connect to demangler.ea.com:3658.
# mohPA does not listen on 3658; Windows SYN retries freeze the GUI ~20s.
DEMANGLER_CONNECT_SKIP = (
    bytes.fromhex("684a0e000068140fc900e8d5690000"),
    bytes.fromhex("684a0e000068140fc90031c0909090"),
)
DEMANGLER_HOST = b"demangler.ea.com"
DEMANGLER_FAILFAST = b"127.0.0.1" + b"\x00" * (len(DEMANGLER_HOST) - len(b"127.0.0.1"))

# Anti-freeze: bypass synchronous CDKey verification wait loop in peerConnect
PEER_CDKEY_WAIT_BYPASS = (
    bytes.fromhex("8b44242485c074466a01"),
    bytes.fromhex("8b44242485c0eb466a01"),
)

# Anti-freeze: bypass synchronous connect handshake wait loop in peerConnect
PEER_CONNECT_WAIT_BYPASS = (
    bytes.fromhex("8b44242485c0744beb03"),
    bytes.fromhex("8b44242485c0eb4beb03"),
)

# Remaining GameSpy Peer SDK sync waits (jz over wait -> jmp). Same family as the two above.
# Only patterns whose hits all sit in the peer SDK (~0x472000-0x473600).
PEER_SYNC_WAIT_EXTRA = [
    (bytes.fromhex("74466a01"), bytes.fromhex("eb466a01")),
    (bytes.fromhex("85c0744beb03"), bytes.fromhex("85c0eb4beb03")),
    (bytes.fromhex("744beb038d49006a01"), bytes.fromhex("eb4beb038d49006a01")),
    (bytes.fromhex("85c07447906a01"), bytes.fromhex("85c0eb47906a01")),
    (bytes.fromhex("74488bff6a01"), bytes.fromhex("eb488bff6a01")),
    (bytes.fromhex("74488d9b000000006a01"), bytes.fromhex("eb488d9b000000006a01")),
    (bytes.fromhex("74498d49006a01"), bytes.fromhex("eb498d49006a01")),
]

# Anti-freeze: reduce Peerchat operation timeout from 60s to 500ms
PEER_OP_TIMEOUT_REDUCE = (
    bytes.fromhex("e814b2fdff0560ea00005f894604"),
    bytes.fromhex("e814b2fdff05f40100005f894604"),
)

# Anti-freeze: accept master server Type 9 (availability echo) as Type 0 and prevent 40s retransmit loop
MASTER_UDP_TYPE9_ACCEPT = (
    bytes.fromhex("39b3b40000007e0689b3b40000008a4802"),
    bytes.fromhex("89b3b40000008a480280f909750230c990"),
)

# Do NOT bypass ServerBrowserWait. That RET skipped ServerBrowserThink, so a
# working master list never landed in the UI. The 20s freeze was demangler:3658.

# SB2 crypt-header start: movzx eax,[edi]; xor eax,0xEC
SB2_CRYPT_HOOK = bytes.fromhex("0fb60735ec000000")
# mohPA 28910 speaks GOA (\basic\secure\...) not SB2/enctypex.
# After the SB2 client connects (and even after it sends an SB2 packet),
# sending a GOA list request returns the compact IP:port list.

# Keep the real FESL login screen if an OpenSpy bypasser rewrote it.
RESTORE_LOGIN_SCREEN = (b"mp_findgame_vet\x00\x00", b"mp_account_login\x00")

AUTOEXEC_CFG = """// mohPA client
seta ui_logged_in "0"
seta ui_hide_internet "0"
seta ui_first_time_mp "0"
seta cl_enableGameSpyAuxiliaryQuery "0"
seta cl_playintro "0"
"""

HOSTS_NAMES = [
    "fesl.ea.com",
    "theater.ea.com",
    "mohpa.fesl.ea.com",
    "mohpa.theater.ea.com",
    "eagames.fesl.ea.com",
    "demangler.ea.com",
    "gpcm.fesl.ea.com",
    "gpsp.fesl.ea.com",
    "peerchat.fesl.ea.com",
    "gamestats.fesl.ea.com",
    "motd.fesl.ea.com",
    "www.mohaa.ea.com",
    "mohaa.ea.com",
    "mohpa.available.fesl.ea.com",
    "mohpa.master.fesl.ea.com",
    "mohpa.ms1.fesl.ea.com",
    "mohpa.ms2.fesl.ea.com",
    "mohpa.ms3.fesl.ea.com",
    "mohpa.ms4.fesl.ea.com",
    "gpcm.gamespy.com",
    "gpsp.gamespy.com",
    "peerchat.gamespy.com",
    "gamestats.gamespy.com",
    "motd.gamespy.com",
    "mohpa.available.gamespy.com",
    "mohpa.master.gamespy.com",
    "gpcm.openspy.net",
    "gpsp.openspy.net",
    "peerchat.openspy.net",
    "gamestats.openspy.net",
    "motd.openspy.net",
    "mohpa.available.openspy.net",
    "mohpa.master.openspy.net",
]


def padded_ip(ip: str, length: int) -> bytes:
    raw = ip.encode("ascii")
    if len(raw) > length:
        raise ValueError(f"IP {ip!r} is longer than slot ({length} bytes)")
    return raw + b"\x00" * (length - len(raw))


def motd_http_prefix(ip: str, length: int = 23) -> bytes:
    """Same-length replacement for http://motd.fesl.ea.com (23 bytes)."""
    raw = b"http://" + ip.encode("ascii")
    if len(raw) > length:
        raise ValueError(f"IP {ip!r} makes MOTD URL longer than the {length}-byte slot")
    return raw + b"/" * (length - len(raw))


def replace_all(data: bytearray, old: bytes, new: bytes) -> int:
    if len(old) != len(new):
        raise ValueError(f"length mismatch {len(old)} != {len(new)} for {old!r}")
    count = bytes(data).count(old)
    if count:
        data[:] = bytearray(bytes(data).replace(old, new))
    return count


def _grow_text_vsize(data: bytearray, new_vsize: int = 0x7B3000) -> None:
    e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
    opt_size = struct.unpack_from("<H", data, e_lfanew + 20)[0]
    sec = e_lfanew + 24 + opt_size
    vsize = struct.unpack_from("<I", data, sec + 8)[0]
    if vsize < new_vsize:
        struct.pack_into("<I", data, sec + 8, new_vsize)


def patch_sb2_goa_bridge(data: bytearray) -> bool:
    """If the SB2 master speaks GOA, request the compact list and import it.

    mohPA :28910 answers with ``\\basic\\secure\\...`` instead of an SB2
    crypt header. The previous cave crashed after login because it:
      * double-cleaned stdcall send/recv (``add esp, 0x10`` after an IAT call)
      * called the SB2 *key-list* parser (0x45BE30) with a fake 7-byte record
    Import each GOA IP:port with SBServerNew + SBServerAdd, then take the
    stock list-complete epilogue at 0x45BDFA.
    """
    hook = data.find(SB2_CRYPT_HOOK)
    if hook < 0 or data[hook] == 0xE9:
        return False

    _grow_text_vsize(data)
    cave_file = 0x7B3C00
    cave_va = 0x00BB3C00
    hook_va = 0x00401000 + (hook - 0x1000)
    send_iat = 0x00BB44CC
    recv_iat = 0x00BB4470
    msleep = 0x00455C50
    sb_new = 0x00459E30
    sb_add = 0x0045B380
    dummy_server = 0x00D38674
    epilogue = 0x0045BDFA

    goa = (
        b"\\gamename\\mohpa\\gamever\\2\\location\\0\\validate\\+QzVFC+b"
        b"\\enctype\\0\\final\\\\queryid\\1.1\\"
    )
    lst = b"\\list\\cmp\\gamename\\mohpa\\final\\"

    def u32(n: int) -> bytes:
        return struct.pack("<I", n)

    def rel32(at: int, src_va: int, dst_va: int, buf: bytearray) -> None:
        buf[at + 1 : at + 5] = struct.pack("<i", dst_va - (src_va + 5))

    def rel8(at: int, target: int, buf: bytearray) -> None:
        r = target - (at + 2)
        if not -128 <= r <= 127:
            raise ValueError(f"rel8 {r} at {at}->{target}")
        buf[at + 1] = r & 0xFF

    c = bytearray()
    # cmp byte [edi], '\\' ; je goa
    c += b"\x80\x3f\x5c"
    je_goa = len(c)
    c += b"\x74\x00"
    c += SB2_CRYPT_HOOK
    jmp_back = len(c)
    c += b"\xe9\x00\x00\x00\x00"
    goa_path = len(c)

    c += b"\x53\x51\x52\x57"  # push ebx, ecx, edx, edi
    c += b"\x81\xec\x00\x08\x00\x00"  # sub esp, 0x800

    # send() / recv() are stdcall — the callee pops the 4 args.
    c += b"\x6a\x00"
    c += b"\x68" + u32(len(goa))
    push_goa = len(c)
    c += b"\x68" + u32(0xDEAD0001)
    c += b"\xff\xb6" + u32(0x4A0)
    c += b"\xff\x15" + u32(send_iat)

    c += b"\x6a\x00"
    c += b"\x68" + u32(len(lst))
    push_lst = len(c)
    c += b"\x68" + u32(0xDEAD0002)
    c += b"\xff\xb6" + u32(0x4A0)
    c += b"\xff\x15" + u32(send_iat)

    c += b"\xbf\x28\x00\x00\x00"  # edi = retries
    c += b"\x33\xed"  # ebp = imported server count
    retry = len(c)
    c += b"\x6a\x00"
    c += b"\x68\x00\x08\x00\x00"
    c += b"\x8d\x44\x24\x08"  # lea eax, [esp+8] recv buffer
    c += b"\x50"
    c += b"\xff\xb6" + u32(0x4A0)
    c += b"\xff\x15" + u32(recv_iat)
    c += b"\x83\xf8\x06"
    jge_got = len(c)
    c += b"\x7d\x00"
    c += b"\x6a\x14"
    msleep_call = len(c)
    c += b"\xe8\x00\x00\x00\x00"
    c += b"\x83\xc4\x04"
    c += b"\x4f\x85\xff"
    jnz_retry = len(c)
    c += b"\x75\x00"
    jmp_finish = len(c)
    c += b"\xeb\x00"

    got = len(c)
    c += b"\x89\xc1"  # ecx = nbytes
    c += b"\x89\xe2"  # edx = buf
    c += b"\x31\xdb"  # ebx = offset
    parse_loop = len(c)
    c += b"\x8d\x43\x06"
    c += b"\x3b\xc1"
    ja_fin = len(c)
    c += b"\x77\x00"
    c += b"\x81\x3c\x1a\x5c\x66\x69\x6e"  # \fin
    je_skip_final = len(c)
    c += b"\x74\x00"
    c += b"\x80\x3c\x1a\x5c"  # '\' leftover GOA keys
    je_slash = len(c)
    c += b"\x74\x00"
    # SBServerNew(slist, ip, port) / SBServerAdd(slist, server)
    c += b"\x51\x52"
    c += b"\x0f\xb7\x44\x1a\x04"  # movzx eax, word [edx+ebx+4]
    c += b"\x50"
    c += b"\xff\x34\x1a"  # push dword [edx+ebx]
    c += b"\x56"
    new_call = len(c)
    c += b"\xe8\x00\x00\x00\x00"
    c += b"\x83\xc4\x0c"
    c += b"\x85\xc0"
    jz_next = len(c)
    c += b"\x74\x00"
    c += b"\x50\x56"
    add_call = len(c)
    c += b"\xe8\x00\x00\x00\x00"
    c += b"\x83\xc4\x08"
    c += b"\x45"  # inc ebp (imported++)
    next_rec = len(c)
    c += b"\x5a\x59"
    c += b"\x83\xc3\x06"
    jmp_parse = len(c)
    c += b"\xeb\x00"
    inc_slash = len(c)
    c += b"\x43"
    jmp_parse_slash = len(c)
    c += b"\xeb\x00"
    skip_final = len(c)
    c += b"\x8d\x43\x07"
    c += b"\x3b\xc1"
    jae_endpkt = len(c)
    c += b"\x73\x00"
    c += b"\x89\xc3"
    jmp_parse_final = len(c)
    c += b"\xeb\x00"
    endpkt = len(c)
    # Banner-only packet: wait for the compact list. Compact \final\: done.
    c += b"\x85\xed"
    jnz_finish_have = len(c)
    c += b"\x75\x00"
    c += b"\x4f\x85\xff"
    jz_finish_retries = len(c)
    c += b"\x74\x00"
    jmp_retry2 = len(c)
    c += b"\xe9\x00\x00\x00\x00"

    finish = len(c)
    c += b"\xc7\x86" + u32(0x5B8) + b"\x05\x00\x00\x00"
    c += b"\xc7\x06\x02\x00\x00\x00"
    c += b"\xff\xb6" + u32(0x484)
    c += b"\xff\x35" + u32(dummy_server)
    c += b"\x6a\x03\x56"
    c += b"\xff\x96" + u32(0x480)
    c += b"\x83\xc4\x10"
    c += b"\x81\xc4\x00\x08\x00\x00"
    c += b"\x5f\x5a\x59\x5b"  # pop edi, edx, ecx, ebx
    c += b"\x33\xed"  # ebp = 0 so the stock epilogue stores inlen 0
    jmp_epi = len(c)
    c += b"\xe9\x00\x00\x00\x00"

    rel8(je_goa, goa_path, c)
    rel32(jmp_back, cave_va + jmp_back, hook_va + 8, c)
    rel8(jge_got, got, c)
    rel8(jnz_retry, retry, c)
    rel8(jmp_finish, finish, c)
    rel8(ja_fin, finish, c)
    rel8(je_skip_final, skip_final, c)
    rel8(je_slash, inc_slash, c)
    rel8(jz_next, next_rec, c)
    rel8(jmp_parse, parse_loop, c)
    rel8(jmp_parse_slash, parse_loop, c)
    rel8(jae_endpkt, endpkt, c)
    rel8(jmp_parse_final, parse_loop, c)
    rel8(jnz_finish_have, finish, c)
    rel8(jz_finish_retries, finish, c)
    rel32(jmp_retry2, cave_va + jmp_retry2, cave_va + retry, c)
    rel32(msleep_call, cave_va + msleep_call, msleep, c)
    rel32(new_call, cave_va + new_call, sb_new, c)
    rel32(add_call, cave_va + add_call, sb_add, c)
    rel32(jmp_epi, cave_va + jmp_epi, epilogue, c)

    while len(c) & 15:
        c += b"\x90"
    goa_off = len(c)
    c += goa + b"\x00"
    lst_off = len(c)
    c += lst + b"\x00"
    c[push_goa + 1 : push_goa + 5] = u32(cave_va + goa_off)
    c[push_lst + 1 : push_lst + 5] = u32(cave_va + lst_off)

    if cave_file + len(c) > 0x7B4000:
        raise ValueError("GOA bridge cave too large")
    data[cave_file : cave_file + len(c)] = c
    rel = cave_va - (hook_va + 5)
    data[hook : hook + 8] = b"\xe9" + struct.pack("<i", rel) + b"\x90\x90\x90"
    return True


def patch_isstats(data: bytearray) -> int:
    matches = list(ISSTATS_RE.finditer(bytes(data)))
    if not matches:
        # Already patched?
        if data.find(ISSTATS_PATCH) >= 0:
            return 0
        return -1
    for m in matches:
        data[m.start() : m.end()] = ISSTATS_PATCH
    return len(matches)


def patch_bytes(data: bytearray, ip: str, is_server: bool) -> List[str]:
    log: List[str] = []
    ip_bytes_cache = {}

    def ip_for(old: bytes) -> bytes:
        if old not in ip_bytes_cache:
            ip_bytes_cache[old] = padded_ip(ip, len(old))
        return ip_bytes_cache[old]

    n = replace_all(data, *SSL_BYPASS)
    if n > 0:
        log.append(f"DirtySDK SSL bypass ({n})")
    elif bytes(data).find(SSL_BYPASS[1]) >= 0:
        log.append("DirtySDK SSL bypass already present")

    n = replace_all(data, *PUSH_PEERCHAT_PORT)
    if n > 0:
        log.append(f"peerchat port 6667 -> {PEERCHAT_PORT} ({n})")
    elif bytes(data).find(PUSH_PEERCHAT_PORT[1]) >= 0:
        log.append(f"peerchat port already {PEERCHAT_PORT}")

    n = patch_isstats(data)
    if n > 0:
        log.append(f"IsStatsConnected always-true ({n})")
    elif n == 0:
        log.append("IsStatsConnected already patched")
    else:
        log.append("WARNING: IsStatsConnected pattern not found")

    for old in MASTER_DOMAINS:
        new = ip_for(old)
        n = replace_all(data, old, new)
        if n:
            log.append(f"{old.decode()} -> {ip} ({n})")

    for old, new in DOMAIN_REPLACEMENTS:
        n = replace_all(data, old, new)
        if n:
            log.append(f"{old.decode()} -> {new.decode()} ({n})")

    for old in DIRECT_CONNECT_HOSTS:
        new = ip_for(old)
        n = replace_all(data, old, new)
        if n:
            log.append(f"{old.decode()} -> {ip} ({n})")

    motd_new = motd_http_prefix(ip)
    for prefix in MOTD_HTTP_PREFIXES:
        n = replace_all(data, prefix, motd_new)
        if n:
            log.append(f"{prefix.decode()} -> {motd_new.decode()} ({n})")

    # Restore any 333networks redirected pointers if present
    redirects = [
        (bytes.fromhex("407ace00"), bytes.fromhex("2409bc00")),
        (bytes.fromhex("5d7ace00"), bytes.fromhex("000abc00")),
        (bytes.fromhex("777ace00"), bytes.fromhex("440cbc00")),
        (bytes.fromhex("ba7ace00"), bytes.fromhex("c033cf00")),
        (bytes.fromhex("cb7ace00"), bytes.fromhex("0835cf00")),
        (bytes.fromhex("8f7ace00"), bytes.fromhex("1025bc00")),
        (bytes.fromhex("a47ace00"), bytes.fromhex("6837cf00")),
    ]
    for old_ptr, orig_ptr in redirects:
        n = replace_all(data, old_ptr, orig_ptr)
        if n:
            log.append(f"reverted redirected pointer {old_ptr.hex()} -> {orig_ptr.hex()} ({n})")

    # Anti-freeze protocol and busy-wait fixes
    n = replace_all(data, *DEMANGLER_CONNECT_SKIP)
    if n:
        log.append(f"demangler TCP 3658 connect skip ({n})")
    n = replace_all(data, DEMANGLER_HOST, DEMANGLER_FAILFAST)
    if n:
        log.append(f"demangler.ea.com -> 127.0.0.1 fail-fast ({n})")
    n = replace_all(data, *GSASTART_BYPASS)
    if n:
        log.append(f"GSIStartAvailableCheck no-op ({n})")
    n = replace_all(data, *PEER_CDKEY_WAIT_BYPASS)
    if n:
        log.append(f"peer CDKey wait bypass ({n})")
    n = replace_all(data, *PEER_CONNECT_WAIT_BYPASS)
    if n:
        log.append(f"peer connect wait bypass ({n})")
    extra_waits = 0
    for old, new in PEER_SYNC_WAIT_EXTRA:
        extra_waits += replace_all(data, old, new)
    if extra_waits:
        log.append(f"peer sync wait bypass extra ({extra_waits})")
    n = replace_all(data, *PEER_OP_TIMEOUT_REDUCE)
    if n:
        log.append(f"peer operation timeout 60s -> 500ms ({n})")
    n = replace_all(data, *MASTER_UDP_TYPE9_ACCEPT)
    if n:
        log.append(f"master server UDP Type 9 auto-ack ({n})")

    if not is_server:
        n = replace_all(data, *GSAVALCHECK_BYPASS)
        if n:
            log.append(f"GameSpy availability check bypass ({n})")
        n = replace_all(data, *RESTORE_LOGIN_SCREEN)
        if n:
            log.append(f"restored mp_account_login ({n})")
        n = replace_all(data, *INTRO_CVAR_DEFAULT)
        if n:
            log.append(f"intro cvar default off ({n})")
        n = replace_all(data, *INTRO_FUNCTION_SKIP)
        if n:
            log.append(f"intro skip ({n})")
        n = replace_all(data, *MUTEX_BYPASS)
        if n:
            log.append(f"mutex multi-instance bypass ({n})")
        n = replace_all(data, *MASTER_RECV_FAST_FIN)
        if n:
            log.append(f"master server fast FIN / anti-freeze ({n})")
        if patch_sb2_goa_bridge(data):
            log.append("SB2 master GOA list bridge")

    return log


def backup(path: str) -> str:
    bak = path + ".bak"
    if not os.path.exists(bak):
        shutil.copy2(path, bak)
        print(f"[+] backup {bak}")
    else:
        print(f"[*] backup exists {bak}")
    return bak


def patch_file(path: str, ip: str, is_server: bool) -> bool:
    if not os.path.exists(path) and not os.path.exists(path + ".bak"):
        print(f"[-] missing {path}")
        return False
    bak = backup(path)
    # Always read from clean backup if available to prevent stacked/corrupted patches
    with open(bak, "rb") as f:
        data = bytearray(f.read())
    log = patch_bytes(data, ip, is_server)
    with open(path, "wb") as f:
        f.write(data)
    print(f"[+] patched {path}")
    for line in log:
        print(f"    - {line}")
    if not log:
        print("    - no matching patterns (already patched or unknown build)")
    return True


def cleanup_conflicting_ui(game_dir: str) -> None:
    for bad_urc in ["shell_mainmenu.urc", "mp_account_login.urc"]:
        p = os.path.join(game_dir, "main", "ui", bad_urc)
        if os.path.exists(p):
            try:
                os.remove(p)
                print(f"[+] removed conflicting UI override: {p}")
            except Exception as e:
                print(f"[-] failed to remove {p}: {e}")
    ui_dir = os.path.join(game_dir, "main", "ui")
    if os.path.exists(ui_dir):
        try:
            if not os.listdir(ui_dir):
                os.rmdir(ui_dir)
                print(f"[+] cleaned empty ui directory: {ui_dir}")
        except Exception:
            pass


def write_hosts(game_dir: str, ip: str) -> str:
    path = os.path.join(game_dir, "mohpa-hosts.txt")
    lines = [
        f"# mohPA hosts - merge into your OS hosts file",
        f"# Windows: C:\\Windows\\System32\\drivers\\etc\\hosts",
        f"# Wine/Whisky: <bottle>/drive_c/windows/system32/drivers/etc/hosts",
        f"# macOS/Linux: /etc/hosts",
        f"#",
        f"# mohPA peerchat listens on TCP {PEERCHAT_PORT} (exe is patched).",
        f"# Also open TCP 18020, 18275, 27900, 28900, 29900, 29920 and UDP 27900.",
        "",
    ]
    width = max(len(ip), 15)
    for name in HOSTS_NAMES:
        # demangler.ea.com:3658 is not on mohPA; mapping it there SYN-times out ~20s.
        host_ip = "127.0.0.1" if name == "demangler.ea.com" else ip
        lines.append(f"{host_ip.ljust(width)}  {name}")
    lines.append("")
    with open(path, "w", newline="\n", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"[+] wrote {path}")
    return path


def write_autoexec(game_dir: str) -> None:
    main_dir = os.path.join(game_dir, "main")
    if not os.path.isdir(main_dir):
        return
    path = os.path.join(main_dir, "autoexec.cfg")
    existing = ""
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            existing = f.read()
    # Ensure ui_logged_in is 0 (must NOT be 1 or login screen is bypassed)
    existing = re.sub(r'seta\s+ui_logged_in\s+"1"', 'seta ui_logged_in "0"', existing)
    existing = re.sub(r'seta\s+cl_enableGameSpyAuxiliaryQuery\s+"1"', 'seta cl_enableGameSpyAuxiliaryQuery "0"', existing)
    if "ui_logged_in" in existing and "cl_enableGameSpyAuxiliaryQuery" in existing and ("mohPA" in existing or "CentralSpy" in existing):
        with open(path, "w", newline="\r\n", encoding="ascii") as f:
            f.write(existing)
        print(f"[*] autoexec updated with clean cvars: {path}")
        return
    # Prepend mohPA cvars; keep any existing lines the user added.
    body = AUTOEXEC_CFG
    if existing.strip():
        body = AUTOEXEC_CFG + "\n" + existing
    with open(path, "w", newline="\r\n", encoding="ascii") as f:
        f.write(body)
    print(f"[+] updated {path}")


def restore_file(path: str) -> bool:
    bak = path + ".bak"
    if not os.path.exists(bak):
        print(f"[-] no backup for {path}")
        return False
    shutil.copy2(bak, path)
    print(f"[+] restored {path}")
    return True


def parse_args(argv: Sequence[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Patch MOHPA for mohPA login")
    p.add_argument("game_dir", nargs="?", default=".", help="folder that contains mohpa.exe")
    p.add_argument("--ip", default=DEFAULT_IP, help=f"mohPA IPv4 (default {DEFAULT_IP})")
    p.add_argument("--restore", action="store_true", help="restore mohpa.exe / mohpa_server.exe from .bak")
    return p.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(sys.argv[1:] if argv is None else argv)
    game_dir = os.path.abspath(args.game_dir)
    print("=" * 64)
    print(" mohPA client patcher")
    print("=" * 64)
    print(f" dir {game_dir}")
    print(f" ip  {args.ip}")
    print()

    client = os.path.join(game_dir, "mohpa.exe")
    server = os.path.join(game_dir, "mohpa_server.exe")

    if args.restore:
        ok = False
        if os.path.exists(client) or os.path.exists(client + ".bak"):
            ok = restore_file(client) or ok
        if os.path.exists(server) or os.path.exists(server + ".bak"):
            ok = restore_file(server) or ok
        return 0 if ok else 1

    if not os.path.exists(client) and not os.path.exists(server) and not os.path.exists(client + ".bak") and not os.path.exists(server + ".bak"):
        print("[-] mohpa.exe not found. Put this patcher in the game folder")
        print("    or: python patcher.py /path/to/MOHPA --ip 178.105.150.25")
        return 1

    try:
        padded_ip(args.ip, 15)
    except ValueError as e:
        print(f"[-] {e}")
        return 1

    if os.path.exists(client) or os.path.exists(client + ".bak"):
        print(f"[*] client {client}")
        patch_file(client, args.ip, is_server=False)
    if os.path.exists(server) or os.path.exists(server + ".bak"):
        print(f"[*] server {server}")
        patch_file(server, args.ip, is_server=True)

    cleanup_conflicting_ui(game_dir)
    write_hosts(game_dir, args.ip)
    write_autoexec(game_dir)
    print()
    print("[+] done. Merge mohpa-hosts.txt into your OS/Wine hosts file,")
    print("    fully quit the game, relaunch, and log in on the Multiplayer screen.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
